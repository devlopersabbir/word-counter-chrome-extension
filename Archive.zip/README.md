# Word Counter FireFox Extension

#

- Get select text count
- Get number of lowercase word
- Get number of uppercase word
- Get number or word
- Get number of letter
- Get number of sentence


***To buy This extension just go to my Buymeacoffe profile***

# 

### Screenshot🔥🔥
![screenshot](./screenshot/1.png)

[Buy Me a Coffee](https://www.buymeacoffee.com/devlopersabbir)

Develop by [Sabbir Hossain Shuvo](https://www.showwcase.com/devlopersabbir)